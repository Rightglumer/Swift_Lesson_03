import Cocoa

enum EngineState {
    case Started, Stopped
}

enum WindowState {
    case Open, Close
}

enum VehicleType {
    case Car, Truck
}

struct Vehicle {
    let yearMade : Int
    let model : String
    let vehicleType : VehicleType
    
    var engineState : EngineState
    var windowState : WindowState
    var maxPassengerCount : Int
    var maxCargoCapacity : Double
    var currentPassengerCount : Int
    var currentCargoCapacity : Double
    
    mutating func startEngine() {
        self.engineState = .Started
    }
    
    mutating func stopEngine() {
        self.engineState = .Stopped
    }
    
    mutating func openWindow() {
        self.windowState = .Open
    }
    
    mutating func closeWindow() {
        self.windowState = .Close
    }
    
    func printVehicleInfo() {
        print("This is \(model), \(yearMade) year.")
        print("It's a \(vehicleType)")
        if vehicleType == .Car {
            print("Max passengers count is \(maxPassengerCount)")
        } else {
            print("Max cargo capacity is \(maxCargoCapacity)")
        }
    }
    
    func printVehicleState() {
        print("The engine is \(engineState)")
        print("Windows are \(windowState)")
        if vehicleType == .Car {
            print("Current passengers count is \(currentPassengerCount) / \(maxPassengerCount)")
        } else {
            print("Current cargo capacity is \(currentCargoCapacity) / \(maxCargoCapacity)")
        }
    }
    
    mutating func addPassenger(count : Int) {
        if vehicleType == .Car {
            if currentPassengerCount + count > maxPassengerCount {
                print("The car is full.")
            } else {
                currentPassengerCount += count
            }
        } else {
            print("Can't take passengers - this is not a taxi!")
        }
    }
    
    mutating func addCargo(value : Double) {
        if vehicleType == .Truck {
            if currentCargoCapacity + value > maxCargoCapacity {
                print("The truck is full.")
            } else {
                currentCargoCapacity += value
            }
        } else {
            print("Can't take a cargo - this is not a gazelle!")
        }
    }
    
    init(yearMade : Int, model : String, vehicleType : VehicleType, passengerCount : Int = 0, cargoCapacity : Double = 0.0) {
        self.yearMade = yearMade
        self.model = model
        self.vehicleType = vehicleType
        self.engineState = .Stopped
        self.windowState = .Close
        self.maxCargoCapacity = cargoCapacity
        self.maxPassengerCount = passengerCount
        self.currentCargoCapacity = 0.0
        self.currentPassengerCount = 0
    }
}

var Dodge = Vehicle(yearMade: 2019, model: "Dodge Viper", vehicleType: VehicleType.Car, passengerCount: 3)
var Gazelle = Vehicle(yearMade: 1998, model: "Gazelle 2752", vehicleType: VehicleType.Truck, cargoCapacity: 10.0)

Dodge.printVehicleInfo()
Dodge.printVehicleState()
print("------")
Dodge.openWindow()
Dodge.addPassenger(count: 3)
Dodge.printVehicleState()
Dodge.addPassenger(count: 1)
print("")
print("")
Gazelle.printVehicleInfo()
Gazelle.printVehicleState()
print("------")
Gazelle.startEngine()
Gazelle.addCargo(value: 7)
Gazelle.printVehicleState()
Gazelle.addPassenger(count: 1)

